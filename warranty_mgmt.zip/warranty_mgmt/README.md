# Warranty Management for Odoo 19

Warranty Management records customer and supplier warranty coverage, tracks lots and serial numbers, handles claims, and reports expiry activity in an Odoo-native dashboard.

## Requirements and installation

- Odoo 19 Community or Enterprise hosted on **Odoo.sh or an on-premise server**. Third-party Python addons are not supported on Odoo Online.
- Install Accounting, Purchase, and Inventory. Inventory is needed for lot and serial traceability.
- Add `warranty_mgmt` to the server add-ons path, update the Apps list, and install **Warranty Management**.
- Assign warranty access groups to users before they use the app.

This release uses the technical addon name `warranty_mgmt`. It does not migrate data from `smr_warranty`, `smr_warranty_account`, `smr_warranty_purchase`, or `smr_warranty_dashboard`.

## First-time setup

1. Open **Settings → Users & Companies → Users** and assign each person a Warranty User, Warranty Manager, or Warranty Admin role.
2. Open the Warranty app and create **Types** (for example, Manufacturer or Extended Service).
3. Create **Policies** with a type, duration, start rule, grace period, reminder period, claim limit, and any covered items or exclusions.
4. Optionally open a product, enable **Warranty Available**, and select a product-specific policy. Invoice and bill registration still asks the user to confirm the policy for the selected items.

Warranty Users can work with records assigned to them in their allowed companies. Managers can access records in their allowed companies and process claims. Admins configure warranty types and policies.

## Register a customer warranty

1. Open a **posted customer invoice** (`Customer Invoices`). Draft invoices and refunds cannot grant customer coverage.
2. Click **Give Customer Warranty**.
3. Select the invoice product lines to cover. For each selected line, choose a policy and check or adjust the start and expiry dates.
4. Choose the delivered lot or serial number when the item is tracked. If completed stock moves are linked to the invoice line, the wizard shows those lots and preselects the single matching lot when there is only one.
5. Confirm. Coverage is linked to the invoice, invoice line, product, and selected lot/serial.

## Register a supplier warranty

1. Open a **posted vendor bill** (`Vendor Bills`).
2. Click **Register Supplier Warranty**.
3. Select the bill product lines to cover, then choose the supplier policy, coverage dates, and received lot or serial number.
4. Confirm. Coverage is linked to the vendor bill and bill line. If the bill line came from a purchase order, its purchase order and purchase order line are retained as well.

Customer invoice coverage and supplier bill coverage are reported separately. The same serial can have one customer warranty and one supplier warranty; duplicate current coverage for the same serial, origin, and company is blocked.

## Find and track coverage

- **Warranty → Coverage**: search by reference, product, lot/serial, customer/vendor, policy, state, or origin. Use the grouping filters to review records by origin, product, partner, policy, or state.
- **Invoice or bill**: use its **Warranties** smart button to open warranties linked to that document.
- **Product**: use the **Warranties** smart button on a product with existing coverage.
- **Dashboard**: review active, expiring, expired, customer invoice, supplier bill, and open claim totals. Select a card or chart row to open its filtered records.
- **Coverage record**: review source details, claims, chatter, and the append-only history tab.

## Process a claim

1. Open the warranty coverage and click **Create Claim** while it is within its claim period, including any configured grace period.
2. Describe the issue and submit the claim.
3. A Warranty Manager reviews it, adds a decision note if rejecting, then **Approves** or **Rejects** it.
4. For an approved claim, record diagnosis or resolution details and click **Resolve** when work is complete.

Claim limits are enforced against the warranty policy. Claim state changes must use the workflow buttons so that validation and warranty history are maintained.

## Expiry reminders

A scheduled daily check marks warranties expired and schedules activities for responsible users and warranty managers. The configured reminder period controls when pre-expiry activities are created. Review the dashboard’s **Expiring Soon** list and each coverage’s History tab for recorded events.

## Data and upgrade notes

Coverage, claims, and history are retained for audit; close coverage through the available workflow actions rather than deleting records. Back up the database before installing or upgrading addons. The new technical name does not automatically migrate existing data from the legacy `smr_warranty*` addons; plan and test a migration separately.

## Support

**Need a customization or new feature?**  
I can help adapt Warranty Management to your business workflows, integrations, reports, and dashboard needs. Email [support@ajith.dev](mailto:support@ajith.dev) with your Odoo version and edition, the apps you use, and a short description of what you need. Visit [ajith.dev](https://ajith.dev).

- Email: [support@ajith.dev](mailto:support@ajith.dev)
- Website: [ajith.dev](https://ajith.dev)
