/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Component, useState, onWillStart } from "@odoo/owl";

export class WarrantyDashboard extends Component {
    static template = "warranty_mgmt.WarrantyDashboard";
    static props = { "*": true };

    setup() {
        this.orm = useService("orm");
        this.actionService = useService("action");

        this.state = useState({
            loading: true,
            data: null,
        });

        onWillStart(async () => {
            await this._loadAll();
        });
    }

    async _loadAll() {
        this.state.loading = true;
        try {
            this.state.data = await this.orm.call(
                "warranty.dashboard", "get_warranty_dashboard_data", []
            );
        } catch (err) {
            console.error("Warranty Dashboard load error:", err);
        }
        this.state.loading = false;
    }

    async onRefresh() {
        await this._loadAll();
    }

    // ----------------------------------------------------------------
    // Navigation
    // ----------------------------------------------------------------
    openRecord(model, resId) {
        this.actionService.doAction({
            type: "ir.actions.act_window",
            res_model: model,
            views: [[false, "form"]],
            res_id: resId,
            target: "current",
        });
    }

    _openList(name, model, domain) {
        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: name,
            res_model: model,
            views: [[false, "list"], [false, "form"]],
            domain: domain || [],
            target: "current",
        });
    }

    _todayStr() {
        return new Date().toISOString().split("T")[0];
    }

    _soonStr() {
        const d = new Date();
        d.setDate(d.getDate() + 30);
        return d.toISOString().split("T")[0];
    }

    // ----------------------------------------------------------------
    // Card -> filtered list actions
    // ----------------------------------------------------------------
    viewActive() {
        this._openList("Active Warranties", "warranty.coverage", [["state", "=", "active"]]);
    }

    viewExpiring() {
        this._openList("Expiring Soon", "warranty.coverage", [
            ["state", "=", "active"],
            ["expiry_date", ">=", this._todayStr()],
            ["expiry_date", "<=", this._soonStr()],
        ]);
    }

    viewExpired() {
        this._openList("Expired Warranties", "warranty.coverage", [["state", "=", "expired"]]);
    }

    viewByOrigin(origin, label) {
        this._openList(label, "warranty.coverage", [["warranty_origin", "=", origin]]);
    }

    viewAllCoverages() {
        this._openList("All Warranties", "warranty.coverage", []);
    }

    viewOpenClaims() {
        this._openList("Open Claims", "warranty.claim", [["state", "in", ["submitted", "approved"]]]);
    }

    viewAllClaims() {
        this._openList("All Claims", "warranty.claim", []);
    }

    viewCoveragesByState(stateKey) {
        this._openList("Warranties", "warranty.coverage", [["state", "=", stateKey]]);
    }

    viewClaimsByState(stateKey) {
        this._openList("Claims", "warranty.claim", [["state", "=", stateKey]]);
    }

    // ----------------------------------------------------------------
    // Chart / badge helpers
    // ----------------------------------------------------------------
    barWidth(list, count) {
        const max = Math.max(...list.map((i) => i.count), 1);
        return Math.max(count ? 3 : 0, Math.round((count / max) * 100));
    }

    coverageBadge(stateKey) {
        const map = {
            draft: "text-bg-secondary",
            active: "text-bg-success",
            expired: "text-bg-danger",
            claimed: "text-bg-warning",
            void: "text-bg-secondary",
            cancelled: "text-bg-secondary",
        };
        return "badge " + (map[stateKey] || "text-bg-primary");
    }

    coverageBarClass(stateKey) {
        const map = {
            draft: "bg-secondary",
            active: "bg-success",
            expired: "bg-danger",
            claimed: "bg-warning",
            void: "bg-secondary",
            cancelled: "bg-secondary",
        };
        return map[stateKey] || "bg-primary";
    }

    claimBarClass(stateKey) {
        const map = {
            draft: "bg-secondary",
            submitted: "bg-warning",
            approved: "bg-info",
            rejected: "bg-danger",
            resolved: "bg-success",
        };
        return map[stateKey] || "bg-primary";
    }

    claimBadge(stateKey) {
        const map = {
            draft: "text-bg-secondary",
            submitted: "text-bg-warning",
            approved: "text-bg-info",
            rejected: "text-bg-danger",
            resolved: "text-bg-success",
        };
        return "badge " + (map[stateKey] || "text-bg-primary");
    }

    daysBadge(daysLeft) {
        if (daysLeft <= 7) return "badge text-bg-danger";
        if (daysLeft <= 15) return "badge text-bg-warning";
        return "badge text-bg-success";
    }
}

registry.category("actions").add("warranty_dashboard", WarrantyDashboard);
